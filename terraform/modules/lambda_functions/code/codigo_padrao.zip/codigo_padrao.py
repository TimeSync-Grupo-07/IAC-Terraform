import json

def handler(event, context)
    
    Função Lambda padrão.
    Recebe um evento e retorna uma resposta JSON simples.
    
    print(Evento recebido, event)
    
    # Exemplo de processamento simples
    response = {
        statusCode 200,
        body json.dumps({
            message Lambda executada com sucesso!,
            input_event event
        })
    }
    
    return response
